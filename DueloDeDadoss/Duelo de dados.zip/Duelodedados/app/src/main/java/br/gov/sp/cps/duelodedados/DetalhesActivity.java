package br.gov.sp.cps.duelodedados;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalhesActivity extends AppCompatActivity {

    private TextView txtDetNome, txtDetDado1Jogador, txtDetDado2Jogador, txtDetTotalJogador;
    private TextView txtDetDado1Pc, txtDetDado2Pc, txtDetTotalPc;
    private TextView txtDetResultado, txtDetClassificacao, txtDetDupla;
    private Button btnVoltarDetalhes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtDetNome = findViewById(R.id.txtDetNome);
        txtDetDado1Jogador = findViewById(R.id.txtDetDado1Jogador);
        txtDetDado2Jogador = findViewById(R.id.txtDetDado2Jogador);
        txtDetTotalJogador = findViewById(R.id.txtDetTotalJogador);
        txtDetDado1Pc = findViewById(R.id.txtDetDado1Pc);
        txtDetDado2Pc = findViewById(R.id.txtDetDado2Pc);
        txtDetTotalPc = findViewById(R.id.txtDetTotalPc);
        txtDetResultado = findViewById(R.id.txtDetResultado);
        txtDetClassificacao = findViewById(R.id.txtDetClassificacao);
        txtDetDupla = findViewById(R.id.txtDetDupla);
        btnVoltarDetalhes = findViewById(R.id.btnVoltarDetalhes);

        // Recebe os dados da última rodada
        String nome = getIntent().getStringExtra("nome");
        int dado1Jogador = getIntent().getIntExtra("dado1Jogador", 0);
        int dado2Jogador = getIntent().getIntExtra("dado2Jogador", 0);
        int totalJogador = getIntent().getIntExtra("totalJogador", 0);
        int dado1Pc = getIntent().getIntExtra("dado1Pc", 0);
        int dado2Pc = getIntent().getIntExtra("dado2Pc", 0);
        int totalPc = getIntent().getIntExtra("totalPc", 0);
        String resultado = getIntent().getStringExtra("resultado");
        String dupla = getIntent().getStringExtra("dupla");

        // Classifica a soma obtida pelo jogador
        String classificacao;
        if (totalJogador <= 5) {
            classificacao = "Soma baixa";
        } else if (totalJogador <= 8) {
            classificacao = "Soma média";
        } else {
            classificacao = "Soma alta";
        }

        txtDetNome.setText("Nome do jogador: " + nome);
        txtDetDado1Jogador.setText("1º dado do jogador: " + dado1Jogador);
        txtDetDado2Jogador.setText("2º dado do jogador: " + dado2Jogador);
        txtDetTotalJogador.setText("Total do jogador: " + totalJogador);
        txtDetDado1Pc.setText("1º dado do computador: " + dado1Pc);
        txtDetDado2Pc.setText("2º dado do computador: " + dado2Pc);
        txtDetTotalPc.setText("Total do computador: " + totalPc);
        txtDetResultado.setText("Resultado da rodada: " + resultado);
        txtDetClassificacao.setText("Classificação da jogada: " + classificacao);
        txtDetDupla.setText(dupla);

        btnVoltarDetalhes.setOnClickListener(view -> finish());
    }
}
