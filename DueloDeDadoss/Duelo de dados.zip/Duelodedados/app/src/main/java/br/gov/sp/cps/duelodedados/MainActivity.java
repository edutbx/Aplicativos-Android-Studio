package br.gov.sp.cps.duelodedados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText editNome;
    private Switch switchMelhorDe3;

    private ImageView dado1, dado2, dado3, dado4;
    private TextView txtNomeJogador, txtSomaJogador, txtSomaComputador;
    private TextView txtResultado, txtDupla, txtPlacar;

    private Button btnJogar, btnDetalhes, btnRegras, btnNovaPartida;

    private int valorDado1, valorDado2, valorDado3, valorDado4;
    private int somaJogador, somaComputador;
    private int pontosJogador = 0;
    private int pontosComputador = 0;

    private String resultadoRodada = "";
    private String infoDupla = "";

    private boolean jogadaRealizada = false;
    private boolean partidaEncerrada = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editNome = findViewById(R.id.editNome);
        switchMelhorDe3 = findViewById(R.id.switchMelhorDe3);

        dado1 = findViewById(R.id.dado1);
        dado2 = findViewById(R.id.dado2);
        dado3 = findViewById(R.id.dado3);
        dado4 = findViewById(R.id.dado4);

        txtNomeJogador = findViewById(R.id.txtNomeJogador);
        txtSomaJogador = findViewById(R.id.txtSomaJogador);
        txtSomaComputador = findViewById(R.id.txtSomaComputador);
        txtResultado = findViewById(R.id.txtResultado);
        txtDupla = findViewById(R.id.txtDupla);
        txtPlacar = findViewById(R.id.txtPlacar);

        btnJogar = findViewById(R.id.btnJogar);
        btnDetalhes = findViewById(R.id.btnDetalhes);
        btnRegras = findViewById(R.id.btnRegras);
        btnNovaPartida = findViewById(R.id.btnNovaPartida);

        // Botão Jogar - sorteia os dados e resolve a rodada
        btnJogar.setOnClickListener(view -> jogarRodada());

        // Botão Detalhes - abre a tela com os dados da última rodada
        btnDetalhes.setOnClickListener(view -> abrirDetalhes());

        // Botão Regras - abre a tela de regras
        btnRegras.setOnClickListener(view -> {
            Intent intent = new Intent(this, RegrasActivity.class);
            startActivity(intent);
        });

        // Botão Nova Partida - zera placar e limpa a tela
        btnNovaPartida.setOnClickListener(view -> novaPartida());

        // Ao ligar/desligar o Melhor de 3, zera placar e imagens para começar do zero
        switchMelhorDe3.setOnCheckedChangeListener((buttonView, isChecked) -> novaPartida());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void jogarRodada() {

        String nome = editNome.getText().toString().trim();

        // Validação: nome obrigatório antes de jogar
        if (nome.isEmpty()) {
            Toast.makeText(this, "Informe seu nome antes de jogar!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validação: impede novas jogadas após o fim da partida no Melhor de 3
        if (partidaEncerrada) {
            Toast.makeText(this, "Partida encerrada! Clique em Nova Partida.", Toast.LENGTH_SHORT).show();
            return;
        }

        txtNomeJogador.setText(nome);

        // Sorteia os quatro valores, entre 1 e 6:
        Random random = new Random();
        valorDado1 = random.nextInt(6) + 1;
        valorDado2 = random.nextInt(6) + 1;
        valorDado3 = random.nextInt(6) + 1;
        valorDado4 = random.nextInt(6) + 1;

        dado1.setImageResource(imagemDoDado(valorDado1));
        dado2.setImageResource(imagemDoDado(valorDado2));
        dado3.setImageResource(imagemDoDado(valorDado3));
        dado4.setImageResource(imagemDoDado(valorDado4));

        // Soma dos dados de cada participante
        somaJogador = valorDado1 + valorDado2;
        somaComputador = valorDado3 + valorDado4;

        txtSomaJogador.setText("Soma: " + somaJogador);
        txtSomaComputador.setText("Soma: " + somaComputador);

        // Verifica se algum participante tirou dupla
        String duplaJogador = (valorDado1 == valorDado2) ? nome + " tirou uma DUPLA! " : "";
        String duplaComputador = (valorDado3 == valorDado4) ? "Computador tirou uma DUPLA!" : "";
        infoDupla = duplaJogador + duplaComputador;
        txtDupla.setText(infoDupla);

        // Compara os totais e define o vencedor da rodada
        if (somaJogador > somaComputador) {
            resultadoRodada = nome + " venceu a rodada!";
            pontosJogador++;
        } else if (somaComputador > somaJogador) {
            resultadoRodada = "Computador venceu a rodada!";
            pontosComputador++;
        } else {
            resultadoRodada = "Rodada empatada!";
        }

        txtPlacar.setText(pontosJogador + " x " + pontosComputador);

        jogadaRealizada = true;

        // Modo Melhor de 3
        if (switchMelhorDe3.isChecked()) {
            if (pontosJogador >= 2) {
                resultadoRodada = nome + " venceu a PARTIDA (Melhor de 3)!";
                partidaEncerrada = true;
            } else if (pontosComputador >= 2) {
                resultadoRodada = "Computador venceu a PARTIDA (Melhor de 3)!";
                partidaEncerrada = true;
            }
        }

        txtResultado.setText(resultadoRodada);
    }

    private int imagemDoDado(int valor) {
        switch (valor) {
            case 1:
                return R.drawable.dice1;
            case 2:
                return R.drawable.dice2;
            case 3:
                return R.drawable.dice3;
            case 4:
                return R.drawable.dice4;
            case 5:
                return R.drawable.dice5;
            default:
                return R.drawable.dice6;
        }
    }

    private void abrirDetalhes() {

        if (!jogadaRealizada) {
            Toast.makeText(this, "Realize uma jogada antes de ver os detalhes!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Cria o Intent e envia os dados da última rodada para a DetalhesActivity
        Intent intent = new Intent(this, DetalhesActivity.class);

        intent.putExtra("nome", editNome.getText().toString().trim());
        intent.putExtra("dado1Jogador", valorDado1);
        intent.putExtra("dado2Jogador", valorDado2);
        intent.putExtra("totalJogador", somaJogador);
        intent.putExtra("dado1Pc", valorDado3);
        intent.putExtra("dado2Pc", valorDado4);
        intent.putExtra("totalPc", somaComputador);
        intent.putExtra("resultado", resultadoRodada);
        intent.putExtra("dupla", infoDupla.isEmpty() ? "Nenhuma dupla nesta rodada." : infoDupla);

        startActivity(intent);
    }

    private void novaPartida() {
        pontosJogador = 0;
        pontosComputador = 0;
        jogadaRealizada = false;
        partidaEncerrada = false;

        dado1.setImageResource(R.drawable.padrao);
        dado2.setImageResource(R.drawable.padrao);
        dado3.setImageResource(R.drawable.padrao);
        dado4.setImageResource(R.drawable.padrao);

        txtSomaJogador.setText("Soma: 0");
        txtSomaComputador.setText("Soma: 0");
        txtResultado.setText("Informe seu nome e clique em Jogar!");
        txtDupla.setText("");
        txtPlacar.setText("0 x 0");
    }
}
