package br.gov.sp.cps.duelodedados;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegrasActivity extends AppCompatActivity {

    private Button btnVoltarRegras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regras);

        btnVoltarRegras = findViewById(R.id.btnVoltarRegras);
        btnVoltarRegras.setOnClickListener(view -> finish());
    }
}
