package br.gov.sp.cps.bancodedados;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    TextView textResultado;
    TextInputEditText textNome, textIdade;
    Button btnGravar, btnConsultar, btnAtualizar, btnDeletar;

    DatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        textResultado = findViewById(R.id.textResultado);
        textNome = findViewById(R.id.textNome);
        textIdade = findViewById(R.id.textIdade);
        btnAtualizar = findViewById(R.id.btnAtualizar);
        btnConsultar = findViewById(R.id.btnConsultar);
        btnGravar = findViewById(R.id.btnGravar);
        btnDeletar = findViewById(R.id.btnDeletar);

        // Gravar
        btnGravar.setOnClickListener(v -> {
            // Entrada de dados
            String nome = textNome.getText().toString();
            String idade = textIdade.getText().toString();


            // Validação de dados
            if (nome.isEmpty() || idade.isEmpty()){
                Toast.makeText(MainActivity.this,
                                "Preencha os dados",
                                Toast.LENGTH_LONG).show();
                return;
            }

            // Caso seja sucesso try / caso não seja catch
            try{
                int numIdade = Integer.parseInt(idade);

                // Chama o db e o método inserir dados:
                if(dbHelper.inserirDados(nome, numIdade)){
                    // Caso a gravação foi realizada com sucesso:
                    Toast.makeText(MainActivity.this,
                            "Dados inseridos com sucesso!",
                            Toast.LENGTH_LONG).show();
                    return;
                }else{
                     // Caso a gravação não foi concluida:
                    Toast.makeText(MainActivity.this,
                            "Erro ao inserir os dados!",
                            Toast.LENGTH_LONG).show();
                    return;
                }
            }catch (NumberFormatException e){
                Toast.makeText(MainActivity.this,
                        "Erro ao inserir os dados",
                        Toast.LENGTH_LONG).show();
                return;
            }

        });

        // Consultar
        btnConsultar.setOnClickListener(v -> {
            // Entrada de dados:
            String nome = textNome.getText().toString();

            // Validação de dados:
            if(nome.isEmpty()){
                Toast.makeText(MainActivity.this,
                        "Digite o nome",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Consulta o nome do DB:
            Cursor cursor = dbHelper.obterIdadePorNome(nome);
            if(cursor != null && cursor.moveToFirst()){
                String idade = cursor.getString(0);
                textResultado.setText("Idade: " + idade);
            } else {
                Toast.makeText(MainActivity.this,
                        "Nome não encontrado",
                        Toast.LENGTH_LONG).show();
                return;
            }

        });

        // Atualizar
        btnAtualizar.setOnClickListener(v -> {
            // Entrada de dados
            String nome = textNome.getText().toString();
            String idade = textIdade.getText().toString();


            // Validação de dados
            if (nome.isEmpty() || idade.isEmpty()){
                Toast.makeText(MainActivity.this,
                        "Preencha os dados",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Caso seja sucesso try / caso não seja catch
            try{
                int numIdade = Integer.parseInt(idade);

                // Chama o db e o método inserir dados:
                if(dbHelper.atualizarDados(nome, numIdade)){
                    // Caso a atualização foi realizada com sucesso:
                    Toast.makeText(MainActivity.this,
                            "Dados atualizados com sucesso!",
                            Toast.LENGTH_LONG).show();
                    return;
                }else{
                    // Caso a atualização não foi concluida:
                    Toast.makeText(MainActivity.this,
                            "Nome não encontrado!",
                            Toast.LENGTH_LONG).show();
                    return;
                }
            }catch (NumberFormatException e){
                Toast.makeText(MainActivity.this,
                        "Idade inválida!",
                        Toast.LENGTH_LONG).show();
                return;
            }

        });

        // Deletar
        btnDeletar.setOnClickListener(v -> {
            // Entrada de dados
            String nome = textNome.getText().toString();


            // Validação de dados
            if (nome.isEmpty()){
                Toast.makeText(MainActivity.this,
                        "Digite o nome",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Deletando os dadso pelo nome:
            if (dbHelper.deletaDados(nome)){
                Toast.makeText(MainActivity.this,
                        "Dados deletados com sucesso!",
                        Toast.LENGTH_LONG).show();
                return;
            } else {
                Toast.makeText(MainActivity.this,
                        "Nome não encontrado!",
                        Toast.LENGTH_LONG).show();
                return;
            }


        });

    }
}