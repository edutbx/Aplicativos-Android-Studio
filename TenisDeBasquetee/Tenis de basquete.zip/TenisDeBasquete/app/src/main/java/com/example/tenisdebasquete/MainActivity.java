package com.example.tenisdebasquete;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imgPadrao;
    private ImageView imgTenis1;
    private ImageView imgTenis2;
    private ImageView imgTenis3;
    private Button btnDetalhes;
    private Button btnLimpar;

    // Guarda o tênis selecionado
    private String opcaoSelecionada = "";

    @Override
    protected void onResume() {
        super.onResume();

        imgPadrao.setImageResource(R.drawable.padrao);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Instanciando os componentes da interface
        imgPadrao = findViewById(R.id.imgPadrao);
        imgTenis1 = findViewById(R.id.imgTenis1);
        imgTenis2 = findViewById(R.id.imgTenis2);
        imgTenis3 = findViewById(R.id.imgTenis3);
        btnDetalhes = findViewById(R.id.btnDetalhes);
        btnLimpar = findViewById(R.id.btnLimpar);

        //Captura de cliques

        imgTenis1.setOnClickListener(view -> {
            opcSelecionada("tenis1");
        });

        imgTenis2.setOnClickListener(view -> {
            opcSelecionada("tenis2");
        });

        imgTenis3.setOnClickListener(view -> {
            opcSelecionada("tenis3");
        });

        //btn detalhes
        btnDetalhes.setOnClickListener(view -> {
            if (opcaoSelecionada.equals("tenis1")) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            } else if (opcaoSelecionada.equals("tenis2")) {
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(intent);
            } else if (opcaoSelecionada.equals("tenis3")){
                Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                startActivity(intent);
            } else {
                return;
            }
        });

        //btn limpar
        btnLimpar.setOnClickListener(view -> {

            // limpa a imagem
            imgPadrao.setImageResource(R.drawable.padrao);

            // apaga histórico de seleção
            opcaoSelecionada = "";

        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void opcSelecionada(String opcao){

        opcaoSelecionada = opcao;

        switch (opcaoSelecionada){
            case "tenis1":
                imgPadrao.setImageResource(R.drawable.adidasownthegame);
                break;

            case "tenis2":
                imgPadrao.setImageResource(R.drawable.precision7);
                break;

            case "tenis3":
                imgPadrao.setImageResource(R.drawable.g);
                break;

        }

    }


}